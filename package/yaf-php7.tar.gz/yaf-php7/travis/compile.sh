#!/bin/sh
phpize && ./configure && make clean && make  
